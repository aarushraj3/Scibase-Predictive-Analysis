import csv
import os.path
from operator import itemgetter

name=[]
#name2=[]
#name3=[]
#name4=[]

path1 = []
directory = '/home/sourav/Documents/Temp_codes/ICR/ICRcumu'
for filename in os.listdir(directory):
	if filename.endswith(".csv"):
		name.append(filename)
		x = os.path.join(directory, filename)
		path1.append(x)

path2 = []
directory = '/home/sourav/Documents/Temp_codes/ICR/ICRdisct'
for filename in os.listdir(directory):
	if filename.endswith(".csv"):
		#name2.append(filename)
		x = os.path.join(directory, filename)
		path2.append(x)

path3 = []
directory = '/home/sourav/Documents/Temp_codes/OCQ/OCQcumu'
for filename in os.listdir(directory):
	if filename.endswith(".csv"):
		#name3.append(filename)
		x = os.path.join(directory, filename)
		path3.append(x)

path4 = []
directory = '/home/sourav/Documents/Temp_codes/OCQ/OCQdisct'
for filename in os.listdir(directory):
	if filename.endswith(".csv"):
		#name4.append(filename)
		x = os.path.join(directory, filename)
		path4.append(x)


path1.sort()
path2.sort()
path3.sort()
path4.sort()

name.sort()
#name2.sort()
#name3.sort()
#name4.sort()



for fl1,fl2,fl3,fl4,nm in zip(path1,path2,path3,path4,name):
	list1=list(csv.reader(file(fl1,'r')))
	list2=list(csv.reader(file(fl2,'r')))
	list3=list(csv.reader(file(fl3,'r')))
	list4=list(csv.reader(file(fl4,'r')))

	list1.sort(key=lambda x:x[0])
	list2.sort(key=lambda x:x[0])
	list3.sort(key=lambda x:x[0])
	list4.sort(key=lambda x:x[0])

	with open(nm, 'a+') as filec:
		fieldnames = ['Year','ICR-cumu-h1','ICR-cumu-h2','ICR-disct-h1','ICR-disct-h2','OCQ-cumu-h1','OCQ-cumu-h2','OCQ-disct-h1','OCQ-disct-h2']
		writer = csv.DictWriter(filec, fieldnames=fieldnames)
		writer.writeheader()

		c=0
		for r1,r2,r3,r4 in zip(list1,list2,list3,list4):
			c+=1
			if c != len(list1):
				print r1
				print r2
				print r3
				print r4
				writer.writerow({'Year':r1[0],'ICR-cumu-h1':r1[1],'ICR-cumu-h2':r1[2],'ICR-disct-h1':r2[1],'ICR-disct-h2':r2[2],'OCQ-cumu-h1':r3[1],'OCQ-cumu-h2':r3[2],'OCQ-disct-h1':r4[1],'OCQ-disct-h2':r4[2]})


'''f1 = file('file1.csv', 'r')
f2 = file('file2.csv', 'r')
#f3 = file('results.csv', 'w')

c1 = csv.reader(f1)
c2 = csv.reader(f2)
#c3 = csv.writer(f3)
list1=list(c1)
list2=list(c2)
c=0'''



